
#include <gtk/gtk.h>
#include "bookmanage.h"

GtkWidget *win1;
GtkTreeSelection *selection;
GtkTreeModel *model;
GtkTreeIter iter;
GtkWidget *view,  *scrolled_win;
//GtkCellRenderer *renderer = gtk_cell_renderer_text_new ();
//void modify_dialog(GtkWidget *win);
static void cell_edited (GtkCellRendererText *renderer,gchar *path,gchar *new_text,GtkTreeView *treeview);
void removeBook1();
void modifyDialog();
void addBookD(GtkTreePath *path);
enum
{
    COL_NO = 0,
  COL_TITLE,
  COL_AUTHOR,
  COL_YEAR,
  COL_ISBN,
  COL_COND,
  NUM_COLS
} ;

void destroy ();
static GtkTreeModel *create_and_fill_model (void)
{
  GtkListStore *store = gtk_list_store_new (NUM_COLS,
                                            G_TYPE_INT,
                                            G_TYPE_STRING,
                                            G_TYPE_STRING,
                                            G_TYPE_STRING,
                                            G_TYPE_STRING,
                                            G_TYPE_STRING);

  /* Append a row and fill in some data */
  //GtkTreeIter iter;
  for(int i = 0; i < counter; i++)
    {
        gtk_list_store_append (store, &iter);
        gtk_list_store_set (store, &iter,
                      COL_NO, (gint)(i + 1),
                      COL_TITLE, bookList[i].title,
                      COL_AUTHOR, bookList[i].author,
                      COL_YEAR, bookList[i].year,
                      COL_ISBN, bookList[i].isbn,
                      COL_COND, bookList[i].cond,
                      -1);

    }



  return GTK_TREE_MODEL (store);
}

static GtkWidget *create_view_and_model (void)
{
    GtkWidget *adj;
    GtkWidget *scwin;
    GtkWidget *vbox;
  GtkWidget *view = gtk_tree_view_new ();

    GtkCellRenderer *renderer;

  /* --- Column #1 --- */
renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (view),
                                               -1,
                                               "No",
                                               renderer,
                                               "text", COL_NO,
                                               NULL);

  renderer = gtk_cell_renderer_text_new ();
 g_object_set (renderer, "editable", TRUE, "editable-set", TRUE, NULL);
 g_signal_connect (G_OBJECT (renderer), "edited",G_CALLBACK (cell_edited),(gpointer) view);

  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (view),
                                               -1,
                                               "Title",
                                               renderer,
                                               "text", COL_TITLE,
                                               NULL);

  /* --- Column #2 --- */
  renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (view),
                                               -1,
                                               "Author",
                                               renderer,
                                               "text", COL_AUTHOR,
                                               NULL);
    renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (view),
                                               -1,
                                               "Year",
                                               renderer,
                                               "text", COL_YEAR,
                                               NULL);

    renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (view),
                                               -1,
                                               "ISBN",
                                               renderer,
                                               "text", COL_ISBN,
                                               NULL);
        renderer = gtk_cell_renderer_text_new ();
  gtk_tree_view_insert_column_with_attributes (GTK_TREE_VIEW (view),
                                               -1,
                                               "Condition",
                                               renderer,
                                               "text", COL_COND,
                                               NULL);
  model = create_and_fill_model ();

  gtk_tree_view_set_model (GTK_TREE_VIEW (view), model);



  /* The tree view has acquired its own reference to the
   *  model, so we can drop ours. That way the model will
   *  be freed automatically when the tree view is destroyed
   */
  g_object_unref (model);

  return view;
}
static void onRowActivated (GtkTreeView        *view,
                GtkTreePath        *path,
                GtkTreeViewColumn  *col,
                gpointer            user_data)
{
  GtkTreeModel *model;
  GtkTreeIter   iter;

  g_print ("Row has been double-clicked. Removing row.\n");

  model = gtk_tree_view_get_model(view);

  if (!gtk_tree_model_get_iter(model, &iter, path))
    return; /* path describes a non-existing row - should not happen */

  gtk_list_store_remove(GTK_LIST_STORE(model), &iter);
}

void listBook (GtkWidget *win)
{

    win1 = win;
    GtkWidget *table;
    view = create_view_and_model ();
    scrolled_win = gtk_scrolled_window_new(NULL,NULL);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win),GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(view));
    //gtk_tree_selection_set_mode(selection, GTK_SELECTION_MULTIPLE);


    table = gtk_table_new(12, 8, TRUE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 2);
    gtk_table_set_col_spacings(GTK_TABLE(table), 2);


    GtkWidget *btn = gtk_button_new_with_label ("Add");
    GtkWidget *btn1 = gtk_button_new_with_label ("Remove");
    GtkWidget *btn2 = gtk_button_new_with_label ("Modify");
    GtkWidget *btn3 = gtk_button_new_with_label ("Back");


    g_signal_connect(btn,"clicked",G_CALLBACK(addBookD),NULL);
    g_signal_connect(btn3,"clicked",G_CALLBACK(destroy),NULL);
    //g_signal_connect(view, "row-activated", G_CALLBACK(onRowActivated), NULL);
    g_signal_connect(btn1,"clicked",G_CALLBACK(removeBook1),NULL);
    g_signal_connect(btn2,"clicked",G_CALLBACK(modifyDialog),NULL);


    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_win), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    gtk_table_attach (GTK_TABLE (table), btn, 2, 3, 9, 10,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), btn1, 3, 4, 9, 10,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), btn2, 4, 5, 9, 10,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), btn3, 5, 6, 9, 10,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach_defaults (GTK_TABLE (table), view, 2, 6, 1, 9);
    //gtk_table_attach_defaults (GTK_TABLE (table), scrolled_win, 2, 5, 4, 9);
    //gtk_container_add (GTK_CONTAINER (win1), scrolled_win);

    gtk_container_add (GTK_CONTAINER (win1), table);


    //gtk_container_add (GTK_CONTAINER (win1), view);

    gtk_widget_show_all (win1);
    //gtk_main ();
}
void addBookD(GtkTreePath *path)
{
    add_dialog(win1);

    GtkTreeModel *model;
    GtkTreeIter iter;

    model = gtk_tree_view_get_model(view);

    //path = gtk_tree_model_get_path (model, &iter);

    //gtk_list_store_append (GTK_LIST_STORE(model), &iter);



        gtk_list_store_append (GTK_LIST_STORE(model), &iter);
        gtk_list_store_set (GTK_LIST_STORE(model), &iter,
                        COL_NO, (gint)(counter + 1),
                      COL_TITLE, bookList[counter].title,
                      COL_AUTHOR, bookList[counter].author,
                      COL_YEAR, bookList[counter].year,
                      COL_ISBN, bookList[counter].isbn,
                      COL_COND, bookList[counter].cond, -1);
    counter++;




}
void removeBook1()
{
    gchar *name;

    if (gtk_tree_selection_get_selected(selection, &view, &iter))
    {


        gtk_tree_model_get (view, &iter, COL_TITLE, &name, -1);

        gtk_list_store_remove(GTK_LIST_STORE(model), &iter);


        g_print ("selected row is: %s\n", name);

        g_free(name);
    }
    for(int i = 0; i < counter; i++)
    {
        if(strcmp(name, bookList[i].title)== 0)
        {
            for(int j = i; j < counter - 1; j++)
            {
                bookList[j] = bookList[j+1];


            }
            counter--;

        }
    }



}
void modifyDialog()
{
    gint no;
    if (gtk_tree_selection_get_selected(selection, &view, &iter))
    {


        gtk_tree_model_get (view, &iter, COL_NO, &no, -1);


        g_print ("selected row is: %d\n", no);
        //g_free(no);
        modify_dialog(win1, no);
        int index = no -1;
        gtk_list_store_set (view, &iter, COL_TITLE, bookList[index].title,COL_AUTHOR, bookList[index].author,
                            COL_YEAR, bookList[index].year,
                            COL_ISBN, bookList[index].isbn,
                            COL_COND, bookList[index].cond,
                            -1);


    }


}

static void cell_edited (GtkCellRendererText *renderer,gchar *path,gchar *new_text,GtkTreeView *treeview)
{
 GtkTreeIter iter;
 GtkTreeModel *model;
 if (g_ascii_strcasecmp (new_text, "") != 0)
 {
    model = gtk_tree_view_get_model (treeview);
 if (gtk_tree_model_get_iter_from_string (model, &iter, path))
    gtk_list_store_set (GTK_LIST_STORE (model), &iter, COL_TITLE, new_text, -1);
 }
}



