#include <gtk/gtk.h>
#include "bookmanage.h"
GtkWidget *txt, *txt1, *txt2,*txt3, *txt4;
GtkWidget *table;
GtkWidget *win1;
GtkWidget *comb;

//struct books book;
struct books
{
    //book properties
    char title[100];
    char author[100];
    char year[100];
    char isbn[100];
    char cond[100];
    //ISBN-13
    //Edition
    //Condition


};
struct books book;
int counter = 0;
struct books bookList[100];
void addBook();



void destroy ();
void copy_text(GtkWidget *wid, gpointer ptr);
void addBook (GtkWidget *win)
{


    win1 = win;
    comb = gtk_combo_box_text_new();
    gtk_combo_box_set_active (GTK_COMBO_BOX (comb), 0);

    table = gtk_table_new(12, 7, TRUE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 2);
    gtk_table_set_col_spacings(GTK_TABLE(table), 2);

    GtkWidget *lbl = gtk_label_new ("Enter Book Title:");
    GtkWidget *lbl1 = gtk_label_new ("Enter Book Author:");
    GtkWidget *lbl2 = gtk_label_new ("Enter Publication Year:");
    GtkWidget *lbl3 = gtk_label_new ("Enter Book ISBN:");
    GtkWidget *lbl4 = gtk_label_new ("Enter Book Condition:");
    GtkWidget *btn2 = gtk_button_new_with_label ("Add");
    GtkWidget *btn3 = gtk_button_new_with_label ("Back");
    g_signal_connect (btn2, "clicked", G_CALLBACK (copy_text), lbl);

    g_signal_connect(btn3,"clicked",G_CALLBACK(destroy),NULL);

    txt = gtk_entry_new ();
    txt1 = gtk_entry_new ();
    txt2 = gtk_entry_new ();
    txt3 = gtk_entry_new ();


     gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (comb),"New");
     gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (comb),"Moderate");
    gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (comb),"Old");


    gtk_table_attach (GTK_TABLE (table), lbl, 1, 2, 2, 3,GTK_EXPAND, GTK_SHRINK, 0,0);


    gtk_table_attach(GTK_TABLE (table), lbl1, 1, 2, 3, 4, GTK_EXPAND, GTK_SHRINK,0,0);
    gtk_table_attach(GTK_TABLE (table), lbl2, 1, 2, 4, 5,GTK_EXPAND, GTK_SHRINK,0,0);
    gtk_table_attach(GTK_TABLE (table), lbl3, 1, 2, 5, 6,GTK_EXPAND, GTK_SHRINK,0,0);
    gtk_table_attach(GTK_TABLE (table), lbl4, 1, 2, 6, 7,GTK_EXPAND, GTK_SHRINK,0,0);


    //gtk_table_attach_defaults (GTK_TABLE (tab), btn, 0, 1, 1, 2);
    gtk_table_attach(GTK_TABLE (table), txt, 2, 5, 2, 3, GTK_FILL, GTK_SHRINK, 5, 5);
    gtk_table_attach(GTK_TABLE (table), txt1, 2, 5, 3, 4,GTK_FILL, GTK_SHRINK,5,5);
    gtk_table_attach(GTK_TABLE (table), txt2, 2, 5, 4, 5,GTK_FILL, GTK_SHRINK,5,5);
    gtk_table_attach(GTK_TABLE (table), txt3, 2, 5, 5, 6,GTK_FILL, GTK_SHRINK,5,5);

    gtk_table_attach(GTK_TABLE (table), comb, 2, 3, 6, 7,GTK_FILL, GTK_SHRINK,5,5);
    //gtk_table_attach(GTK_TABLE (table), chk1, 3, 4, 6, 7,GTK_FILL, GTK_SHRINK,5,5);


    gtk_table_attach(GTK_TABLE (table), btn2, 3, 4, 7, 8,GTK_FILL, GTK_SHRINK,5,5);
    gtk_table_attach(GTK_TABLE (table), btn3, 0, 1, 0, 1, GTK_FILL, GTK_SHRINK,5,5);
    gtk_container_add (GTK_CONTAINER (win1), table);
    gtk_widget_show_all(win1);
    //gtk_main ();
}
void destroy ()
{
    //gtk_main_quit ();
    gtk_container_foreach(win1, G_CALLBACK(gtk_widget_destroy), NULL);
    //gtk_widget_destroy(win1);
    menu(win1);
}
void copy_text(GtkWidget *wid, gpointer ptr)
{
    char *input = gtk_entry_get_text (GTK_ENTRY (txt));

    char *input1 = gtk_entry_get_text (GTK_ENTRY (txt1));
    char *input2 = gtk_entry_get_text (GTK_ENTRY (txt2));
    char *input3 = gtk_entry_get_text (GTK_ENTRY (txt3));

    //int cond1 = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (chk));

    int *input4 =gtk_combo_box_text_get_active_text (GTK_COMBO_BOX_TEXT (comb));


    char bookTitle[100];
    strcpy( book.title, input);
    strcpy( book.author, input1);
    strcpy( book.year, input2);
    strcpy( book.isbn, input3);
    strcpy( book.cond, input4);
    //int cond = cond1;
    //book.year = input2;
    bookList[counter] = book;
    counter++;
    gtk_entry_set_text (GTK_ENTRY (txt),"");
    gtk_entry_set_text (GTK_ENTRY (txt1),"");
    gtk_entry_set_text (GTK_ENTRY (txt2),"");
    gtk_entry_set_text (GTK_ENTRY (txt3),"");

}

