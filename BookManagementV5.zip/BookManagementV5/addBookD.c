#include <gtk/gtk.h>

void add_dialog(GtkWidget *win)
{

    GtkWidget *dlg, *table,*txt, *txt1, *txt2,*txt3, *txt4;
    GtkTreeIter iter, child;
    dlg = gtk_dialog_new_with_buttons("Add a new Book",NULL,GTK_DIALOG_MODAL, "Add",0,"Cancel",1, NULL);

    comb = gtk_combo_box_text_new();
    gtk_combo_box_set_active (GTK_COMBO_BOX (comb), 0);
    gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (comb),"New");
    gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (comb),"Moderate");
    gtk_combo_box_text_append_text (GTK_COMBO_BOX_TEXT (comb),"Old");

    GtkWidget *lbl = gtk_label_new ("Book Title:");
    GtkWidget *lbl1 = gtk_label_new ("Book Author:");
    GtkWidget *lbl2 = gtk_label_new ("Publication Year:");
    GtkWidget *lbl3 = gtk_label_new ("Book ISBN:");
    GtkWidget *lbl4 = gtk_label_new ("Book Condition:");

    table = gtk_table_new(6, 3, TRUE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 2);
    gtk_table_set_col_spacings(GTK_TABLE(table), 2);

    gtk_table_attach (GTK_TABLE (table), lbl, 0, 1, 0, 1,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), lbl1, 0, 1, 1, 2,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), lbl2, 0, 1, 2, 3,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), lbl3, 0, 1, 3, 4,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), lbl4, 0, 1, 4, 5,GTK_FILL, GTK_SHRINK,0,0);

    txt = gtk_entry_new ();
    txt1 = gtk_entry_new ();
    txt2 = gtk_entry_new ();
    txt3 = gtk_entry_new ();


    gtk_table_attach (GTK_TABLE (table), txt, 1, 2, 0, 1,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), txt1, 1,2 , 1, 2,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), txt2, 1, 2, 2, 3,GTK_FILL, GTK_SHRINK,0,0);
    gtk_table_attach (GTK_TABLE (table), txt3, 1, 2, 3, 4,GTK_FILL, GTK_SHRINK,0,0);

    gtk_table_attach (GTK_TABLE (table), comb, 1, 2, 4, 5,GTK_FILL, GTK_SHRINK,0,0);

   //
    //gtk_container_add (GTK_CONTAINER (dlg), table);
    gtk_container_add (GTK_CONTAINER (gtk_dialog_get_content_area (GTK_DIALOG (dlg))),table);
    gtk_widget_show_all (dlg);
    int count = gtk_dialog_run(GTK_DIALOG(dlg));
    g_print("The button is: %d\n", count);
    if(count == 0)
       {
        char *input = gtk_entry_get_text (GTK_ENTRY (txt));

        char *input1 = gtk_entry_get_text (GTK_ENTRY (txt1));
        char *input2 = gtk_entry_get_text (GTK_ENTRY (txt2));
        char *input3 = gtk_entry_get_text (GTK_ENTRY (txt3));

        //int cond1 = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (chk));

        int *input4 =gtk_combo_box_text_get_active_text (GTK_COMBO_BOX_TEXT (comb));


        char bookTitle[100];
        strcpy( book.title, input);
        strcpy( book.author, input1);
        strcpy( book.year, input2);
        strcpy( book.isbn, input3);
        strcpy( book.cond, input4);
        //int cond = cond1;
        //book.year = input2;
        bookList[counter] = book;

        gtk_entry_set_text (GTK_ENTRY (txt),"");
        gtk_entry_set_text (GTK_ENTRY (txt1),"");
        gtk_entry_set_text (GTK_ENTRY (txt2),"");
        gtk_entry_set_text (GTK_ENTRY (txt3),"");
       }
    gtk_widget_destroy(dlg);

}
