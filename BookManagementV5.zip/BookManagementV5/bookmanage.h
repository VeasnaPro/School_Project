#ifndef BOOKMANAGE_H_INCLUDED
#define BOOKMANAGE_H_INCLUDED

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "AddBooks.c"
#include "Remove.c"
#include "Search.c"
#include "test.c"
#include "menu.c"
#include "listBooks.c"
#include "modifyD.c"
#include "addBookD.c"



void copy_text (GtkWidget *wid, gpointer ptr);
void remove_book(GtkWidget *wid, gpointer ptr);

void end_program (GtkWidget *wid, gpointer ptr);
void modify_dialog(GtkWidget *win, gint no);
void add_dialog(GtkWidget *win);
void addBook (GtkWidget *win);
void removeBook(GtkWidget *win);
void searchBook(GtkWidget *win);

void listBook(GtkWidget *win);
void menu(GtkWidget *win);
void button_Add();
void button_Remove();
void button_Search();

void modifyDialog();
void addBookD(GtkTreePath *path);
void end_program (GtkWidget *wid, gpointer ptr);
void destroy();



#endif // BOOKMANAGE_H_INCLUDED
