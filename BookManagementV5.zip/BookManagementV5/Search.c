#include <gtk/gtk.h>
GtkWidget *txt;
GtkWidget *win1;
void destroy ();
void copy_text(GtkWidget *wid, gpointer ptr);

void searchBook(GtkWidget *win)
{
    win1 = win;
    GtkWidget *table;



    /*gtk_init (&argc, &argv);
    GtkWidget *win = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    /*GtkWidget *btn = gtk_button_new_with_label ("Close window");
    g_signal_connect (btn, "clicked", G_CALLBACK (end_program),
    NULL);
    g_signal_connect (win, "delete_event", G_CALLBACK (end_program),
    NULL);
    table = gtk_table_new(12, 7, TRUE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 2);
    gtk_table_set_col_spacings(GTK_TABLE(table), 3);
    GtkWidget *lbl = gtk_label_new ("Enter Book Title:");
    GtkWidget *btn2 = gtk_button_new_with_label ("Search");
    GtkWidget *btn3 = gtk_button_new_with_label ("Back");
    g_signal_connect (btn2, "clicked", G_CALLBACK (copy_text), lbl);
    g_signal_connect(btn3,"clicked",G_CALLBACK(destroy),NULL);
    txt = gtk_entry_new ();

    gtk_table_attach_defaults (GTK_TABLE (table), lbl, 1, 2, 4, 5);
    gtk_table_attach_defaults (GTK_TABLE (table), btn2, 3, 4, 5, 6);
    //gtk_table_attach_defaults (GTK_TABLE (tab), btn, 0, 1, 1, 2);
    gtk_table_attach_defaults (GTK_TABLE (table), txt, 2, 5, 4, 5);
    gtk_table_attach_defaults (GTK_TABLE (table), btn3, 0, 1, 0, 1);
    gtk_container_add (GTK_CONTAINER (win1), table);*/
    gtk_widget_show_all (win1);
    //gtk_main ();
}

