
#include "bookmanage.h"

/*struct books
{
    //book properties
    char title[100];
    char author[100];
    int year;

};
struct books bookList[100];
void addBook();*/

GtkWidget *win = NULL;

int main(int argc, char *argv[]) {

  GtkWidget *window;
  //GtkWidget *table;
  //GtkWidget *button;



  gtk_init(&argc, &argv);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  //gtk_window_set_default_size(GTK_WINDOW(window), 250, 250);
  gtk_widget_set_size_request (window, 500, 500);
  gtk_window_set_title(GTK_WINDOW(window), "BookManagement");
    menu(window);

  g_signal_connect(G_OBJECT(window), "destroy",
        G_CALLBACK(gtk_main_quit), NULL);

  gtk_widget_show_all(window);

  gtk_main();

  return 0;
}




