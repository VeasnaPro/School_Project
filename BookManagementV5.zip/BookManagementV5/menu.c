#include <gtk/gtk.h>
//#include "bookmanage.h"

GtkWidget *win1;
void button_Add();
void button_Remove();
void button_Search();
void button_Quality();
void end_program (GtkWidget *wid, gpointer ptr);
void menu(GtkWidget *win)
{
    /*GtkWidget *window;

  //GtkWidget *button;*/
  GtkWidget *table;
    win1 = win;
  gchar *values[16] = { "Add Books", "Remove Old Books", "List All Books", "Close", "CRUD LIBRARY"};

  //gtk_init(&argc, &argv);

  /*window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  //gtk_window_set_default_size(GTK_WINDOW(window), 250, 250);
  gtk_widget_set_size_request (window, 500, 500);
  */
  gtk_window_set_title(GTK_WINDOW(win1), "GtkTable");
  GtkWidget *lbl = gtk_label_new ("BOOK MANAGEMENT SYSTEM");
  gtk_container_set_border_width(GTK_CONTAINER(win1), 5);

  table = gtk_table_new(7, 7, TRUE);
  gtk_table_set_row_spacings(GTK_TABLE(table), 2);
  gtk_table_set_col_spacings(GTK_TABLE(table), 2);



    //button = gtk_button_new_with_label(values[5]);
    gtk_table_attach(GTK_TABLE(table), lbl, 3, 4, 0, 1,GTK_EXPAND,GTK_EXPAND,10,10);

    GtkWidget *btn1 = gtk_button_new_with_label(values[0]);
    gtk_table_attach(GTK_TABLE(table), btn1, 2, 3, 1, 2,GTK_FILL, GTK_FILL,10,10);


    GtkWidget *btn2 = gtk_button_new_with_label(values[1]);
    gtk_table_attach(GTK_TABLE(table), btn2, 2, 3, 3, 4, GTK_FILL, GTK_FILL, 10,10);

    GtkWidget *btn3 = gtk_button_new_with_label(values[2]);
    gtk_table_attach(GTK_TABLE(table), btn3, 4, 5, 1, 2, GTK_FILL, GTK_FILL,10,10);

    GtkWidget *btn4 = gtk_button_new_with_label(values[3]);
    gtk_table_attach(GTK_TABLE(table), btn4, 4, 5, 3, 4, GTK_FILL, GTK_FILL, 10,10);




    //gtk_widget_set_size_request(button, 150, 80);
    g_signal_connect(btn1,"clicked",G_CALLBACK(button_Add),NULL);
    g_signal_connect(btn2,"clicked",G_CALLBACK(button_Remove),NULL);
    g_signal_connect(btn3,"clicked",G_CALLBACK(button_Search),NULL);
    g_signal_connect(btn4,"clicked",G_CALLBACK(end_program ),NULL);



  gtk_container_add(GTK_CONTAINER(win1), table);

  gtk_widget_show_all(win1);



  return 0;
}

void button_Add(){
    gtk_container_forall(win1, G_CALLBACK(gtk_widget_destroy), NULL);
    addBook(win1);
}

void button_Remove(){
    gtk_container_forall(win1, G_CALLBACK(gtk_widget_destroy), NULL);
    removeBook(win1);
}
void button_Search(){
    gtk_container_forall(win1, G_CALLBACK(gtk_widget_destroy), NULL);
    listBook(win1);
}
void end_program (GtkWidget *wid, gpointer ptr)
{
 gtk_main_quit ();
}

