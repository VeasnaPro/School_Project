
#include <gtk/gtk.h>
GtkWidget *win1;

GtkWidget *txt;
void destroy ();
void copy_text(GtkWidget *wid, gpointer ptr);
void bookQuality (GtkWidget *win)
{
    win1 = win;
    GtkWidget *table;


    table = gtk_table_new(12, 7, TRUE);
    gtk_table_set_row_spacings(GTK_TABLE(table), 2);
    gtk_table_set_col_spacings(GTK_TABLE(table), 3);

    gtk_container_add (GTK_CONTAINER (win), table);
    gtk_widget_show_all (win);
    //gtk_main ();
}


